var init = (function () {
    'use strict';

    const { Shell, Gio } = imports.gi;
    const RemoteSearch = imports.ui.remoteSearch;
    const Util = imports.misc.util;
    const DOMAIN_NAME = 'com.github.harshadgavali';
    const BASE_ID = `${DOMAIN_NAME}.SearchProvider`;
    const BASE_PATH = `/${DOMAIN_NAME.replace(/\./g, '/')}/SearchProvider`;
    const SEARCH_PROVIDERS_SCHEMA = 'org.gnome.desktop.search-providers';
    const EXENAME = `${DOMAIN_NAME}.tabsearchproviderconnector`;
    class WebBrowserTabSearchProvider extends RemoteSearch.RemoteSearchProvider2 {
        constructor(appInfo, dbusName, dbusPath, autoStart) {
            super(appInfo, dbusName, dbusPath, autoStart);
            this.id = `tabsearchprovider.${dbusName}`;
            this.isRemoteProvider = true;
            this.canLaunchSearch = false;
        }
        async getInitialResultSet(terms, cancellable) {
            try {
                const [results] = await this.proxy.GetInitialResultSetAsync(terms, cancellable);
                return results;
            }
            catch (error) {
                this._handleGioDbusError(error);
                return [];
            }
        }
        async getSubsearchResultSet(previousResults, newTerms, cancellable) {
            try {
                const [results] = await this.proxy.GetSubsearchResultSetAsync(previousResults, newTerms, cancellable);
                return results;
            }
            catch (error) {
                this._handleGioDbusError(error);
                return [];
            }
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        _handleGioDbusError(error) {
            if (!(error === null || error === void 0 ? void 0 : error.matches(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED)) &&
                !(error === null || error === void 0 ? void 0 : error.matches(Gio.DBusError, Gio.DBusError.SERVICE_UNKNOWN))) {
                log(`Received error from D-Bus search provider ${this.id}: ${error}`);
            }
        }
    }
    function getProvider(app, appName) {
        if (!app)
            return;
        const appInfo = app.get_app_info();
        appInfo.get_description = () => `List of tabs open in ${appInfo}`;
        appInfo.get_name = () => `${appName} Tabs`;
        return new WebBrowserTabSearchProvider(appInfo, `${BASE_ID}.${appName}`, `${BASE_PATH}/${appName}`, true);
    }
    class BrowserTabExtension {
        constructor() {
            this._searchSettings = new Gio.Settings({ schema_id: SEARCH_PROVIDERS_SCHEMA });
            this._loadRemoteSearchProviders = RemoteSearch.loadRemoteSearchProviders;
            this._appIds = [
                { id: 'firefox.desktop', name: 'Firefox' },
                { id: 'microsoft-edge.desktop', name: 'Edge' },
                { id: 'org.chromium.Chromium.desktop', name: 'Chromium' },
            ];
            this._appIds.reverse();
            const appSystem = Shell.AppSystem.get_default();
            // eslint-disable-next-line @typescript-eslint/no-this-alias
            const extensionThis = this;
            RemoteSearch.loadRemoteSearchProviders = function (searchSettings) {
                const providers = extensionThis._loadRemoteSearchProviders(searchSettings);
                extensionThis._appIds.forEach(app => {
                    const provider = getProvider(appSystem.lookup_app(app.id), app.name);
                    if (provider)
                        providers.unshift(provider);
                });
                return providers;
            };
            this._reloadProviders();
        }
        destroy() {
            RemoteSearch.loadRemoteSearchProviders = this._loadRemoteSearchProviders;
            this._reloadProviders();
            Util.spawn(['/usr/bin/killall', EXENAME]);
        }
        _reloadProviders() {
            this._searchSettings.set_boolean('disable-external', true);
            this._searchSettings.set_boolean('disable-external', false);
        }
    }

    imports.gi;
    const { windowAttentionHandler, activateWindow } = imports.ui.main;
    class WindowAttentionHandlerExtension {
        constructor() {
            if (windowAttentionHandler._windowDemandsAttentionId)
                global.display.block_signal_handler(windowAttentionHandler._windowDemandsAttentionId);
            if (windowAttentionHandler._windowMarkedUrgentId)
                global.display.block_signal_handler(windowAttentionHandler._windowMarkedUrgentId);
            this._signalIds = [
                global.display.connect('window-demands-attention', this._windowDemandsAttention.bind(this)),
                global.display.connect('window-marked-urgent', this._windowDemandsAttention.bind(this)),
            ];
        }
        destroy() {
            this._signalIds.reverse().forEach(id => global.display.disconnect(id));
            this._signalIds = [];
            if (windowAttentionHandler._windowMarkedUrgentId)
                global.display.unblock_signal_handler(windowAttentionHandler._windowMarkedUrgentId);
            if (windowAttentionHandler._windowDemandsAttentionId)
                global.display.unblock_signal_handler(windowAttentionHandler._windowDemandsAttentionId);
        }
        _windowDemandsAttention(_display, window) {
            if (!window || window.skip_taskbar)
                return;
            activateWindow(window);
        }
    }

    class Extension {
        constructor() {
            this._extensions = [];
        }
        enable() {
            this._extensions = [
                new BrowserTabExtension(),
                new WindowAttentionHandlerExtension(),
            ];
        }
        disable() {
            this._extensions.reverse().forEach(extension => extension.destroy());
            this._extensions = [];
        }
    }
    function init() {
        return new Extension();
    }

    return init;

})();
