const {
	      byteArray,
	      gi: { GLib }
      } = imports;

// ES6 mandates var to be used when exporting
// intel_pstate/intel_cpufreq
var CPU_INTEL         = 0;
// acpi-cpufreq/amd-pstate
var CPU_AMD           = 1;
var CPU_NOT_SUPPORTED = 2;

function getMyCpuType()
{
	const out = GLib.spawn_command_line_sync( `bash -c "cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_driver"` )[ 1 ];

	if ( out.length )
	{
		const driver = byteArray.toString( out ).trim();

		if ( [ 'intel_pstate', 'intel_cpufreq' ].includes( driver ) && GLib.spawn_command_line_sync( `bash -c "cat /sys/devices/system/cpu/intel_pstate/no_turbo"` )[ 1 ].length )
		{
			return CPU_INTEL;
		}
		else if ( [ 'amd-pstate', 'acpi-cpufreq' ].includes( driver ) && GLib.spawn_command_line_sync( `bash -c "cat /sys/devices/system/cpu/cpufreq/boost"` )[ 1 ].length )
		{
			return CPU_AMD;
		}
	}

	return CPU_NOT_SUPPORTED;
}