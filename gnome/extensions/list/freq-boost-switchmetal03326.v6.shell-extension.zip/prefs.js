const {
	      byteArray,
	      gi  : {
		      Gtk: { Label, Switch, Box, Grid, Separator, Button, ListStore, ComboBox, CellRendererText },
		      GLib,
		      GObject
	      },
	      misc: { extensionUtils }
      } = imports;
const _ = extensionUtils.gettext;

function init()
{
	extensionUtils.initTranslations();
}

function buildPrefsWidget()
{
	const spacing = 8;
	const pkexec  = GLib.spawn_command_line_sync( `bash -c "pkexec --version"` )[ 1 ];
	const grid    = new Grid( {
		margin_top   : spacing * 3,
		margin_bottom: spacing * 3,
		margin_start : spacing * 3,
		margin_end   : spacing * 3,
		row_spacing  : spacing * 2,
		visible      : true
	} );

	if ( pkexec.length )
	{
		const me            = extensionUtils.getCurrentExtension();
		const { common }    = me.imports;
		const myCpuType     = common.getMyCpuType();
		const cpuSupportBox = new Box( { spacing } );
		let cpuSupportLabel = _( 'Sorry, your CPU is NOT supported!' );

		if ( myCpuType !== common.CPU_NOT_SUPPORTED )
		{
			cpuSupportLabel = _( 'Supported {{VENDOR}} CPU detected!' ).replace( '{{VENDOR}}', myCpuType === common.CPU_INTEL ? 'Intel' : 'AMD' );
		}

		cpuSupportBox.append( new Label( { label: cpuSupportLabel } ) );

		grid.attach( cpuSupportBox, 0, 0, 1, 1 );

		if ( myCpuType !== common.CPU_NOT_SUPPORTED )
		{
			const settings         = extensionUtils.getSettings();
			const settingSwitch    = new Switch( { active: settings.get_boolean( 'persist' ) } );
			const settingSwitchBox = new Box( { spacing } );
			const settinsButtonBox = new Box( { spacing } );
			const versionString    = byteArray.toString( pkexec ).trim();
			const version          = Number( versionString.slice( versionString.search( /\d/ ) ) );

			settingSwitch.connect( 'notify::active', ( { active } ) => settings.set_boolean( 'persist', active ) );

			settingSwitchBox.append( new Label( { label: _( 'Persist' ) } ) );
			settingSwitchBox.append( settingSwitch );

			grid.attach( new Separator, 0, 1, 1, 1 );
			grid.attach( settingSwitchBox, 0, 2, 1, 1 );
			grid.attach( new Label( { label: _( 'Warning! This will make permissions dialog to appear 5s after login (only if boost\nneeds to be changed).' ) } ), 0, 3, 1, 1 );
			grid.attach( new Separator, 0, 4, 1, 1 );

			if ( version >= 0.106 )
			{
				const addButton    = new Button( { label: _( 'Add Rules' ) } );
				const removeButton = new Button( { label: _( 'Remove Rules' ) } );

				addButton.connect( 'clicked', () => GLib.spawn_command_line_async( `pkexec bash -c "cp ${me.dir.get_child( 'freq-boost-switch.rules' ).get_path()} /etc/polkit-1/rules.d/"` ) );
				removeButton.connect( 'clicked', () => GLib.spawn_command_line_async( `pkexec bash -c "rm -f /etc/polkit-1/rules.d/freq-boost-switch.rules"` ) );

				settinsButtonBox.append( addButton );
				settinsButtonBox.append( removeButton );

				grid.attach( new Label( { label: _( 'You can get rid of the permissions dialog by adding rules to the Polkit. By clicking\nthose buttons you will add/remove /etc/polkit-1/rules.d/freq-boost-switch.rules' ) } ), 0, 5, 1, 1 );
				grid.attach( settinsButtonBox, 0, 6, 1, 1 );
			}
			else
			{
				grid.attach( new Label( { label: _( 'Your Polkit version is too old. Update it to at least 0.106 to be able to get rid of\nthe permissions dialog.' ) } ), 0, 5, 1, 1 );
			}

			if ( myCpuType === common.CPU_INTEL )
			{
				// EPB is supported
				if ( GLib.spawn_command_line_sync( `bash -c "cat /sys/devices/system/cpu/cpu0/power/energy_perf_bias"` )[ 1 ].length )
				{
					const titleBox = new Box( { spacing } );
					const offBox   = new Box( { spacing } );
					const onBox    = new Box( { spacing } );
					const model    = new ListStore();
					const renderer = new CellRendererText();

					model.set_column_types( [ GObject.TYPE_STRING, GObject.TYPE_STRING ] );

					[
						[ '-1', _( 'No change' ) ],
						[ '0', 'performance' ],
						[ '4', 'balance-performance' ],
						[ '6', 'normal' ],
						[ '8', 'balance-power' ],
						[ '15', 'power' ]
					].forEach( row => model.set( model.append(), [ 0, 1 ], row ) );

					[ [ 'epb-off', _( 'OFF' ), offBox ], [ 'epb-on', _( 'ON' ), onBox ] ].forEach( ( [ setting, state, box ] ) =>
					{
						const comboBox        = new ComboBox( { model } );
						const targetValue     = settings.get_int( setting ).toString();
						let [ success, iter ] = model.get_iter_first();

						comboBox.pack_start( renderer, true );
						comboBox.add_attribute( renderer, 'text', 1 );
						comboBox.set_id_column( 0 );

						comboBox.connect( 'changed', _ => settings.set_int( setting, Number( comboBox.get_active_id() ) ) );

						while ( success && model.get_value( iter, 0 ) !== targetValue )
						{
							success = model.iter_next( iter );
						}

						comboBox.set_active_iter( iter );

						box.append( new Label( { label: _( 'When I switch frequency boost to {{STATE}} set {{NAME}} to' ).replace( '{{STATE}}', state ).replace( '{{NAME}}', 'EPB' ) } ) );
						box.append( comboBox );
					} );

					titleBox.append( new Label( { label: `Intel Performance and Energy Bias Hint (EPB), ${_( 'for all cores' )}` } ) );

					// We start adding at index 7
					[ new Separator, titleBox, offBox, onBox ].forEach( ( item, index ) => grid.attach( item, 0, 7 + index, 1, 1 ) );
				}

				const epp = GLib.spawn_command_line_sync( `bash -c "cat /sys/devices/system/cpu/cpu0/cpufreq/energy_performance_available_preferences"` )[ 1 ];

				// EPP is supported
				if ( epp.length )
				{
					const titleBox = new Box( { spacing } );
					const offBox   = new Box( { spacing } );
					const onBox    = new Box( { spacing } );
					const model    = new ListStore();
					const renderer = new CellRendererText();

					model.set_column_types( [ GObject.TYPE_STRING, GObject.TYPE_STRING ] );

					[
						[ '-1', _( 'No change' ) ],
						...byteArray.toString( epp ).trim().split( ' ' ).map( value => [ value, value ] )
					].forEach( row => model.set( model.append(), [ 0, 1 ], row ) );

					[ [ 'epp-off', _( 'OFF' ), offBox ], [ 'epp-on', _( 'ON' ), onBox ] ].forEach( ( [ setting, state, box ] ) =>
					{
						const comboBox        = new ComboBox( { model } );
						const targetValue     = settings.get_string( setting );
						let [ success, iter ] = model.get_iter_first();

						comboBox.pack_start( renderer, true );
						comboBox.add_attribute( renderer, 'text', 1 );
						comboBox.set_id_column( 0 );

						comboBox.connect( 'changed', _ => settings.set_string( setting, comboBox.get_active_id() ) );

						while ( success && model.get_value( iter, 0 ) !== targetValue )
						{
							success = model.iter_next( iter );
						}

						comboBox.set_active_iter( iter );

						box.append( new Label( { label: _( 'When I switch frequency boost to {{STATE}} set {{NAME}} to' ).replace( '{{STATE}}', state ).replace( '{{NAME}}', 'EPP' ) } ) );
						box.append( comboBox );
					} );

					titleBox.append( new Label( { label: `Intel Energy-Performance Preference (EPP), ${_( 'for all cores' )}` } ) );

					// We start adding at index 11
					[ new Separator, titleBox, offBox, onBox ].forEach( ( item, index ) => grid.attach( item, 0, 11 + index, 1, 1 ) );
				}
			}
		}
	}
	else
	{
		grid.attach( new Label( { label: _( 'pkexec not found. Extension will not operate properly.' ) } ), 0, 1, 1, 1 );
	}

	grid.show();

	return grid;
}