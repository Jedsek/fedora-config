var PYTHON_SCRIPT_PATH = 'Bluetooth_Headset_Battery_Level/bluetooth_battery.py';
var BTCTL_SCRIPT_PATH = 'scripts/bluetoothctl_battery.sh'
var UPOWER_SCRIPT_PATH = 'scripts/upower_battery.sh'
var TOGGLE_SCRIPT_PATH = 'scripts/bluetoothctl_toggle.sh';
