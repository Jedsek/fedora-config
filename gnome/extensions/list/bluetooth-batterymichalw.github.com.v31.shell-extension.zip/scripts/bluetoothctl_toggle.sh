#!/bin/bash

command=$(bluetoothctl $2 $1)
echo 'ok'
