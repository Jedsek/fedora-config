# Battery Time

This extension serves as a replacement of battery remaining time,last seen in GNOME 42,so I made it an extension to get the feature back.

Remaining time is shown inline, so no additional menu item is created (currently).

The extension works on GNOME 43 and 44 (needs more test). Of course, previous GNOME versions don't need this extension.

## License
This program is distributed under the terms of the GNU General Public License, version 2 or later.
