
var Base = /*abstract*/ class {
    constructor() {
        //this.enable()
    }
    enable() {}
    disable() {}
}
