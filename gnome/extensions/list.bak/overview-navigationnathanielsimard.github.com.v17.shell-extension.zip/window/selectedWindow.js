var SelectedWindow = class SelectedWindow {
  constructor (window, updateLabelCallback, overview) {
    this.window = window
    this.updateLabelCallback = updateLabelCallback
    this.overview = overview
  }

  updateTag (tag) {
    this.updateLabelCallback(tag)
  }

  close () {
    const time = global.get_current_time()
    this.window.delete(time)
  }

  focus () {
    const time = global.get_current_time()
    this.window.activate(time)
    this.overview.hide()
  }

  toBeFocus () {
    this.activate = this.focus
  }

  toBeClose () {
    this.activate = this.close
  }
}

var Factory = class Factory {
  create (window, updateLabelCallback, overview) {
    return new SelectedWindow(window, updateLabelCallback, overview)
  }
}


