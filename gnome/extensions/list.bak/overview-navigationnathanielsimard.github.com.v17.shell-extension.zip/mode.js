var MODE = {
  Closing: 'Closing',
  Focussing: 'Focussing'
}


